#!/usr/bin/env python3
"""
Phishing Email Sender - FIXED Imports
Interactive Gmail sender.
"""
import smtplib
import json
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
import os

print("🦈 SmartBus Phishing Email Sender")
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = input("Sender Gmail: ")
SMTP_PASS = input("App Password: ")
RECIPIENTS = [r.strip() for r in input("Recipients (comma sep): ").split(',')]

TRACK_ID = "sim1"

def load_template():
    with open("email_template.html", "r", encoding='utf-8') as f:
        html = f.read()
    return html.replace('track_id=email1', f'track_id={TRACK_ID}')

def send(to_email):
    msg = MIMEMultipart()
    msg['Subject'] = "🚨 SmartBus Password Reset - Urgent"
    msg['From'] = SMTP_USER
    msg['To'] = to_email
    html_part = MIMEText(load_template(), 'html')
    msg.attach(html_part)
    
    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.send_message(msg)
        
        log = {"event": "sent", "to": to_email, "track_id": TRACK_ID, "time": datetime.utcnow().isoformat()}
        print(f"✅ Sent to {to_email}")
        with open("phish_results.json", "a") as f:
            f.write(json.dumps(log) + "\n")
        return True
    except Exception as e:
        print(f"❌ {e}")
        return False

sent = sum(send(r) for r in RECIPIENTS)
print(f"Sent {sent}/{len(RECIPIENTS)}. View: python analyze_phish.py")

