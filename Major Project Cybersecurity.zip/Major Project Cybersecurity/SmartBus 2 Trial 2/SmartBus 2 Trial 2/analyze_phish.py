#!/usr/bin/env python3
"""
Phishing Simulation Metrics Analyzer
Parse phish_results.jsonl and compute interaction funnel metrics.
"""
import json
from collections import Counter
from datetime import datetime

def load_phish_logs():
    """Load all phish events from phish_results.json (NDJSON)."""
    events = []
    try:
        with open('phish_results.json', 'r') as f:
            for line in f:
                if line.strip():
                    events.append(json.loads(line))
    except FileNotFoundError:
        print("No phish_results.json found. Run simulation first.")
        return []
    return events

def normalize_event(event):
    mapping = {
        'track-open': 'open',
        'track-click': 'click', 
        'phish-reset': 'reset'
    }
    return mapping.get(event, event)

def compute_metrics(events):
    """Compute key metrics: opens, clicks, data_attempts, reports."""
    event_types = Counter(normalize_event(e.get('event', 'unknown')) for e in events)
    usernames = set(e.get('username') or e.get('email', '') for e in events if e.get('username') or e.get('email'))
    
    # Data entry attempts (detailed phish-reset)
    attempts = [e for e in events if normalize_event(e.get('event', '')) == 'reset']
    unique_attempts = len(set(e.get('track_id') for e in attempts))
    
    # Reports
    reports = len([e for e in events if e.get('event') == 'report'])
    
    # Funnel
    opens = event_types['open']
    clicks = event_types['click']
    
    print("=== Phishing Simulation Metrics ===")
    print(f"📊 Total Events: {len(events)}")
    print(f"👥 Unique Users/Tracks: {len(usernames)}")
    print(f"👁️  Email Opens: {opens}")
    print(f"🖱️  Link Clicks: {clicks}")
    print(f"⌨️  Data Entry Attempts: {len(attempts)} (unique: {unique_attempts})")
    print(f"🚨 Reports: {reports}")
    print(f"📉 Click-to-Attempt Rate: {len(attempts)/max(clicks,1)*100:.1f}%")
    
    if attempts:
        print("\n🔥 Top Attempted Users:")
        user_attempts = Counter(e.get('username') or e.get('email', 'unknown') for e in attempts)
        for user, count in user_attempts.most_common(5):
            print(f"  - {user}: {count}")
    
    print("\n📈 Event Breakdown:")
    for event, count in sorted(event_types.items()):
        print(f"  {event}: {count}")

if __name__ == "__main__":
    events = load_phish_logs()
    if events:
        compute_metrics(events)
    else:
        print("No events to analyze. Send phishing emails and test!")

